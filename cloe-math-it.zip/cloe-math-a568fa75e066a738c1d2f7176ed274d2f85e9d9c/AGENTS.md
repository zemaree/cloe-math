# AGENTS.md — Cloe Math

Compact instructions for agents working in this repo. Trust executable sources (`index.html`, `sw.js`, `manifest.webmanifest`) over `README.md` — the README is stale (see below).

## Overview

- Single-file PWA: an Italian multiplication/division practice app for a tablet, built for one child ("Cloe") plus parent/teacher consult and practice modes.
- No framework, no build system, no package manager. GitHub Pages serves the raw files from the repo root; Firebase/Firestore is the only progress store.
- Everything an agent does here is: edit the inline CSS/JS in `index.html`, keep `sw.js` cache knobs in sync, and push to `main`.

## Files (the whole repo)

- `index.html` — the entire app: `<style>` blocks, app JS, Firebase SDK `<script src>` tags, and the cloud/login IIFE. Also carries `<meta http-equiv="Cache-Control" content="no-store">`.
- `sw.js` — service worker: offline cache bootstrap + network-first fetch for app documents.
- `manifest.webmanifest` — PWA manifest (`lang: it`, no `icons`).
- `README.md` — user-facing setup/deploy notes; partially wrong, see Discrepancies.
- `firestore.rules` — **mirror of the applied Firestore rules, documentation only**: nothing in the app reads it, the applied copy lives in the Firebase Console for `cloe-math` (there is no `firebase.json`/service account, so publishing is manual). Keep its `// rules-status:` header line truthful, and do **not** add it to `sw.js` `FILES`.

## How the page is wired (not obvious from filenames)

- One shared global scope across three script regions in `index.html`. The app script declares `function save(){renderStats();renderCalendar()}`; the later cloud IIFE **rebinds** it: `save = function(){persist();renderStats();renderCalendar()}`. All progress writes go through that override — there is no `localStorage` anywhere in the repo.
- The cloud IIFE reads DOM ids declared earlier in the HTML (`cloudLogin`, `cloudLoginForm`, `cloudProfile`, `cloudPassword`, `cloudLoginButton`, `cloudLoginError`, `cloudToolbar`, `cloudMode`, `cloudRealMode`, `cloudPracticeMode`, `cloudLogout`, `adminOpen`, `adminPanel`, `resetData`, `dashboard`, `summary`, `layout`). Renaming an id means editing **both** the markup and the JS.
- Role/permission gating is hardcoded: `profiles` maps `cloe`/`parent`/`teacher` to a fixed Firebase `uid` + email; login calls `auth.signOut()` if `user.uid` doesn't match the selected role. Cloe only ever sees `mode==="real"`; parent/teacher toggle `real` (consult) vs `practice`; the admin reset panel opens only for `role==="parent" && mode==="real"`.
- Firestore layout: `students/cloe` (real progress) vs `practice/<uid>` (parent/teacher scratch), each `{progress, updatedAt}`. Never write Cloe's real doc from parent/teacher roles.
- Visibility of parent view is CSS-driven via `body.cloud-parent` classes plus `setParentView()` — DOM is hidden, not removed, so app buttons remain in the tree.
- The identity/mode toolbar (`#cloudToolbar`: `#cloudMode` label + `#cloudRealMode`/`#cloudPracticeMode`/`#cloudLogout` buttons) now lives **inside `<header>`, as its third flex child**, so it inherits `.app>header{position:sticky;top:0;z-index:30}` and stays visible at the top while the dashboard/calendar scroll. `setToolbar()` is the only writer of its text and button visibility. Because the header is sticky, the sticky `.question` band needs a bigger `top` in the short-screen media queries (`top:96px` portrait, `top:86px` landscape) or it slides under the header.

## Commands

There is no install/build/test/lint command and no dependency manifest. Do not invent one. The Firebase SDK is loaded from `gstatic` at v10.14.1 (compat API: `firebase-app`/`firebase-auth`/`firebase-firestore`), with no vendored copy.

- Local dev: serve the folder over **localhost or HTTPS**, never `file://` — `file://` silently disables service-worker registration and the Web Speech API (`it-IT` dictation).
  `python -m http.server 8000` (then open `http://localhost:8000/`).
- Deploy: push to `main`; Pages is manual ("Settings → Pages → Deploy from a branch → `main`, folder `/`"). There is no CI workflow to run.
- **Every push must declare rule drift in the commit body**, since Firestore rules are the only artifact outside git. Use two trailers, e.g.
  `Rules: no change` or `Rules: update required — add parent uid to allow create,update on /students/cloe` (or `Rules: applied — same`).
  Also state the cache pair: `Cache: v27 (sw.js CACHE + index.html register)`. Keep the `// rules-status:` line of `firestore.rules` in sync with what the Console actually applies.
- Ad-hoc verification of the inline scripts: extract each `<script>` region and run `node --check` on it (Node is the only practical syntax check; there is no parser config in the repo).

## Version-number rules

The visible app version is `1.MINOR.FIX` (currently `1.8.0`), written identically in 3 places in `index.html`. Move all three in one edit.

- A **minor/feature change** (UI moved, new behaviour, copy reworded) bumps the **2nd digit**.
- A **fix** (logic bug, wrong output, blocked action) bumps the **3rd digit**.
- Keep the 1st digit unless the app is rewritten. A change that is both fix and minor bumps both digits.
- The `sw.js` cache counter (`cloe-math-vNN` + `./sw.js?v=NN`) is an **independent** number: bump it on *any* change to an app document, in the same commit, on both sides. Never add `firestore.rules` to `FILES`.

## Operational gotchas

- **Cache knobs must move together.** `sw.js` top line `const CACHE='cloe-math-vNN'` and the registration URL in `index.html` `navigator.serviceWorker.register('./sw.js?v=NN', ...)` are two separate knobs; the repo's git history is largely these bumps. Change both in the same commit, and update `const FILES=['./','./index.html','./manifest.webmanifest']` whenever a new asset is added — it is a hand-maintained list.
- `activate` deletes any cache whose key starts with `cloe-math-` except the current one, so a version bump is how stale offline HTML is invalidated.
- `Versione 1.8.0` appears 3 times in `index.html` (header `#appVersion`, login card `#loginVersion`, footer). Keep them in sync, and bump them by the digit rule above (minor → 2nd digit, fix → 3rd digit), never one at a time.
- `index.html` is UTF-8 **without BOM** and full of accented Italian strings. Never rewrite it with PowerShell `>`/`Set-Content` (UTF-16) — use file-writing tools that keep UTF-8. `core.autocrlf=true` locally: the index stores LF, the working tree may show CRLF.
- Firestore rules are the **only non-git artifact**: `firestore.rules` mirrors them, the Console applies them. The one write that is not uid-self-matched is the admin reset on `students/cloe`, so a rules gap shows up **only** as the `permission-denied` alert from the reset `catch` — consult reads, Cloe's own writes and `practice/<uid>` all keep working, which makes the breakage look partial. As of 2026-11-22 the Console **applies** this file (parent uid granted on `create,update` for `students/cloe`), so the parent reset succeeds and that alert should not appear — keep the `// rules-status:` line truthful, because a gap is still invisible except through that alert.
- Firebase config (apiKey/project `cloe-math`) plus per-role `uid`+email are hardcoded in `index.html`; there is no `.env`, no secret file. Don't add a second copy of the project credentials elsewhere, and don't move the file — it is public by design.
- Firestore writes are queued on `saveChain` and failures only `console.error("Cloud sync failed")`. Navigation (mode switch, logout) must `await saveChain` first or the last answer is lost; the reset panel already does. Both mode-switch handlers also early-return on `role==="cloe"||!user`, so Cloe can never leave `mode==="real"` even from the console.
- `normalize()` (cloud IIFE) re-seeds `days[today]={correct:0,total:0,seconds:[]}` on every load **and** on reset, so a "cleared" `students/cloe` doc still carries today's empty bucket; `renderStats()`/`submit()` index `data.days[today]` directly and depend on that guarantee.
- The admin reset clears only `students/cloe` (via `normalize(blank())`: empty `days`/`mistakes`/`answers`/`history`, `points:0`, `programStart` = today). `practice/<uid>` docs are never deleted or cleaned — there is no client-side way to list or purge them. Reset waits only on the current tab's `saveChain`, so a second open tab (e.g. Cloe's) can still write stale progress back after the reset.
- Skips share the answering path: `submit(value,skipped)` stores `answer:null` in `history`/`answers`, records no `seconds`, gives `+0` points, but still does `d.total++` — skips count toward the daily goal. `renderHistory()` prints `non lo so` for `x.answer===null`.
- **The session slot and the daily goal are two different numbers**, and the 15-day program is a third. Session slot: `sessionDeadline=Date.now()+10*60*1000` (10 minutes) over a `for(let i=0;i<120;i++)` draw pool — the slot, not the pool, is what ends a session, and `$('bar')` stays count-based (`index/120`). Daily goal: `const dailyGoal=30,dailyPrize=dailyGoal*2;` (declared once in the app region, right before `currentLevel()`) is the single source for the JS sites: `submit()` gate `d.total>=dailyGoal` awards `data.points+=dailyPrize` once via `dailyBonusAwarded`, `completeDay()`/streak, the `0/30` card (`d.total+'/'+dailyGoal`) and the generated prize/feedback copy, and the `renderStats()` level bar now reads the `levelRungs` table, not `dailyGoal` (see the level-rung bullet below). **The only drift left is markup literals**, which must move in the same edit whenever the goal changes: `>0/30<` in the `#done` card and `Completa 30 ` in the calendar panel copy.
- The goal is pace-derived, not guessed: 600 s slot ÷ (15 s answer ceiling + ~1.5 s UI) = ~36 possible, so 30 leaves one question of slack — challenging but reachable; 50 would require the 10 s pace. Her real pace is only visible through `best`/`dashAverage`, never as a UI number.
- **Progression is one table, six levels.** `const levelRungs=[{t:0,a:0},{t:40,a:.75},{t:100,a:.82},{t:220,a:.85},{t:360,a:.88},{t:500,a:.9}]` (declared next to `dailyGoal`) is the single source for `currentLevel()` — which walks it **descending**, so existing docs only ever promote, never demote — and for the `renderStats()` bar and `dashNextLevel` copy (`next=level<levelRungs.length?levelRungs[level].t:null`, `prev=levelRungs[level-1].t`, pct interpolates between the two). The gates are **literal totals** (40/100/220/360/500) with accuracy floors .75/.82/.85/.88/.90: they are no longer multiples of `dailyGoal`, so the daily goal and the level gates are independent numbers now. `levelNames` and `levelDescriptions` must stay **length 6** (both indexed `level-1`), and `makeSession()`'s `coefficient=[1,1.2,1.3,1.4,1.5,1.6]` must stay **length 6** — a shorter array yields `undefined` → `NaN` weights → an empty `sessionPool` at level 6.
- **`buildPool(level)` is unlock-staged** and is called with the level (`buildPool(level)`, not `buildPool()`): base 1–10 ×/÷ always; `level>=3` appends the 11 and 12 facts; `level>=4` appends missing-operand variants that **share** the base key (`7x8`, `56d7`) so retries keep reinforcing, but carry `q` (`? × 7 = 56`) and `g` (`Missing number × 7`); `level>=5` appends two-step `(a × b) ± k` items with `a:null,b:null,op:''` and their own key (`(3x3)+2`); `level>=6` also 11/12-based two-step. Every consumer must tolerate the new shapes: `showQuestion()` renders `current.q||current.a+' '+current.op+' '+current.b` and toggles the `.long` class when the rendered text exceeds 9 chars (CSS defines `.question.long` in the main block **and** in both media queries), `submit()`/`renderHistory()` repeat that same `q||…` fallback, `renderMastery()` groups by `x.g||…`. `data.answers` entries now also carry `q` and `g` (additive fields, old docs lack them).
- **Combo streak**: `combo`/`sessionBest` are app-region `let`s; reset in `makeSession()` and `$('startExercises').onclick`; a correct answer does `combo++` and raises the lifetime `data.bestCombo`, and bonus stars fire **only** at `combo===5` (+5) and `combo===10` (+10) — no guard flag needed since combo increments by 1, but keep that property if you ever change the step. Wrong/skip sets `combo=0`. `bestCombo` is a lifetime field: `blank()` seeds `bestCombo:0` and `normalize()` does `d.bestCombo??=0`; `firestore.rules` is field-agnostic so it needs no rules change.
- **Dictation ceiling**: `parseItalianNumber()` understands 1–3 digits plus words only up to 99 (units/exact/tens/tens+units). The 11/12 tables and the `level>=6` two-step items produce products up to 144 and results above 99, for which the voice path returns `null` (typed answers still work). This gap pre-existed at 100 and the new content widens it — flag it, do not silently rewrite the parser.
- `programDay()` is **uncapped** now (`Math.max(1,Math.floor((now-start)/86400000)+1)`): the 15-lesson program is a phase map, not a hard target, and the day counter keeps counting after day 15. `$('cycleBar')` clamps (`Math.min(100,day/15*100)`), `$('cycleDay')` switches to the past-15 copy at `day>15`, and the dashboard heading says the program continues.
- If the Firebase scripts fail to load (offline), the cloud IIFE's `try/catch` runs `showError(...)` and `save` is **not** overridden: the app still plays but progress is never persisted. Offline PWA usage therefore shows blank progress.

## README discrepancies (trust code, fix README if asked)

1. README says progress is stored "locally in the browser using LocalStorage" — there is no `localStorage`; persistence is Firestore-only via `persist()`.
2. README says "Ten-question practice rounds" — the app runs a **timed 10-minute session** (`sessionDeadline = Date.now() + 10*60*1000`) of **120 drawn exercises** (`for(let i=0;i<120;i++)` over `sessionPool`). The daily goal is now `dailyGoal=30` attempts (`d.total>=dailyGoal` awards `dailyPrize = dailyGoal*2` = `+60` stars once, via `dailyBonusAwarded`, and marks the calendar day `completed`; `completeDay()` also accepts legacy `d.completed===true`).
3. README claims an "installable PWA manifest" — `manifest.webmanifest` has **no `icons`** (or screenshots), which Chrome install prompts generally require.
4. README never mentions Firebase login, roles, or the `students` vs `practice` docs, yet the app is unusable without a Firebase project (`cloe-math`) with email sign-in enabled and Firestore rules allowing those writes — the required shape is written down in `firestore.rules`, including the parent uid grant the admin reset needs.
5. `sw.js` was bumped to `cloe-math-v23` while `index.html` still registered `./sw.js?v=22` (HEAD commit touched only `sw.js`) — verify they match after any change. They currently **do** match (both `v29`).

## Conventions

- UI copy is informal Italian with intentional misspellings ("risposta", "allenarti"); match the existing register when editing strings and never switch language.
- Code style here is minified single-`function`-per-line JS with `$=document.getElementById` shorthand, DOM-id-based state, `class="hidden"` toggling, and no modules/exports. Follow it for in-file edits; don't reformat the whole file.
- Dates are keyed `YYYY-MM-DD` via `toLocaleDateString('sv-SE')` (`dateKey()`/`today`), which is what the calendar and streak logic depend on.
- Keep role gating and Firestore paths untouched when touching reset/cleanup logic.
